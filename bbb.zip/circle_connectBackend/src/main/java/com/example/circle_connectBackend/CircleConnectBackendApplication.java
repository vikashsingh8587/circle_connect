package com.example.circle_connectBackend;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class CircleConnectBackendApplication {

	public static void main(String[] args) {
		SpringApplication.run(CircleConnectBackendApplication.class, args);
	}

}
