package com.example.circle_connectBackend.dto;

public class LoginRequests {
}
