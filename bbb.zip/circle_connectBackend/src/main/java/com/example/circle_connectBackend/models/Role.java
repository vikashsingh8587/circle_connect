package com.example.circle_connectBackend.models;

public enum Role {
    ADMIN,
    USER,
    DONER,
    RECIPIENT,
}
