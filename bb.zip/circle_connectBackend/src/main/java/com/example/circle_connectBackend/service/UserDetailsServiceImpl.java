package com.example.circle_connectBackend.service;

import com.example.circle_connectBackend.models.User;
import com.example.circle_connectBackend.repository.userRepository;
import com.example.circle_connectBackend.repository.userRepository;
import lombok.AllArgsConstructor;
import lombok.NoArgsConstructor;
import lombok.RequiredArgsConstructor;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.core.userdetails.*;
import org.springframework.stereotype.Service;

import java.util.Collections;

@Service
@AllArgsConstructor
@NoArgsConstructor
@RequiredArgsConstructor
public class UserDetailsServiceImpl implements UserDetailsService {
    @Autowired
    private userRepository repo;



    @Override
    public UserDetails loadUserByUsername(String input) throws UsernameNotFoundException {
        User user;
        if (input.contains("@")) {
            user = repo.findByEmail(input).orElseThrow(() -> new UsernameNotFoundException("username not fournt" + input));

        }else{
            user = repo.findByUsername(input).orElseThrow(() -> new UsernameNotFoundException("username not fournt" + input));

        }
        return  new org.springframework.security.core.userdetails.User(
                String.valueOf(user.getId()),
                user.getPassword(),
                Collections.singleton(()->"Role"+user.getRole())

        );
    }
}
